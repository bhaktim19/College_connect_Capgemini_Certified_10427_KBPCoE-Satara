

package com.edu;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


public class MainApp {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure("hibenate.cfg.xml");
		
		config.addAnnotatedClass(Student.class);
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		Student sob = new Student("Bhakti","bhakti@ex.com",61000);
		Student sob1 = new Student("Ganesh","ganesh@ex.com",61000);
		
		session.save(sob);
		session.save(sob1);
		
        Student s = session.get(Student.class, 2); //select * from student_table where sid=2
        System.out.println(s.toString());
        
        session.delete(s);
        
        	
		tx.commit();
		session.close();
		
		
		

	}

}
