package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MAinAppEmployee {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure("hibenate.cfg.xml");
		
		config.addAnnotatedClass(Employee.class);
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		Employee eob = new Employee("Bhakti","bhakti@ex.com",60000);
		
		session.save(eob);
		tx.commit();
		session.close();

	}

}
