package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_table")
public class Employee {
	@Id
	@Column(name = "eid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int employeeId;
	@Column(name = "eemail", length=50, nullable = false, unique = true)
	private String employeeEmail;
	@Column(name = "ename", length=50, nullable = false)
	private String employeeName;
	@Column(name = "esalary")
	private float employeeSalaray;
	public Employee(String employeeEmail, String employeeName, float employeeSalaray) {
		super();
		this.employeeEmail = employeeEmail;
		this.employeeName = employeeName;
		this.employeeSalaray = employeeSalaray;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeEmail() {
		return employeeEmail;
	}
	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public float getEmployeeSalaray() {
		return employeeSalaray;
	}
	public void setEmployeeSalaray(float employeeSalaray) {
		this.employeeSalaray = employeeSalaray;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeEmail=" + employeeEmail + ", employeeName="
				+ employeeName + ", employeeSalaray=" + employeeSalaray + "]";
	}
	
	

}
