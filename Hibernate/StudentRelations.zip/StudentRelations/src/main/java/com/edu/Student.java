package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "student_details")
public class Student {
	
	@Id
	@Column(name= "sid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int StudentID;
	
	@Column(name= "sname", length = 50, nullable = false)
	private String studentName;
	
	@Column(name="sage", length = 50, nullable = false)
	private int studentAge;
	
	@ManyToOne
	@JoinColumn(name = "cid")
	Courses cou;
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String studentName, int studentAge) {
		super();
		this.studentName = studentName;
		this.studentAge = studentAge;
	}

	public int getStudentID() {
		return StudentID;
	}

	public void setStudentID(int studentID) {
		StudentID = studentID;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}

	@Override
	public String toString() {
		return "Student [StudentID=" + StudentID + ", studentName=" + studentName + ", studentAge=" + studentAge + "]";
	}
	
	

}
