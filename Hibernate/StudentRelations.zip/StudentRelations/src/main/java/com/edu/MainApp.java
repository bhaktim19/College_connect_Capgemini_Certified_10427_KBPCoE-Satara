package com.edu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



public class MainApp {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure().addAnnotatedClass(Student.class).addAnnotatedClass(Courses.class);
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Courses c = new Courses("Web Dev Fundamentals", 60000f);
		
		Student s1 = new Student("Sagar", 22);
		Student s2 = new Student("Sarika", 21);
		
		List<Student> sList = new ArrayList<Student>();
		sList.add(s1);
		sList.add(s2);
		
		c.setsList(sList);
		
		session.save(c);
		
		tx.commit();
		session.close();
		

	}

}
