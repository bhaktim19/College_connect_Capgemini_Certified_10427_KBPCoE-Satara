package com.edu;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="course_details")
public class Courses {
	
	@Id
	@Column(name = "cid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int courseID;
	
	@Column(name= "cname", length = 50, nullable = false, unique = true)
	private String courseName;
	
	@Column(name= "cfees")
	private float courseFee;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "cid")
	List<Student> sList = new ArrayList<Student>();
	
	public List<Student> getsList() {
		return sList;
	}

	public void setsList(List<Student> sList) {
		this.sList = sList;
	}

	public Courses() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Courses(String courseName, float courseFee) {
		super();
		this.courseName = courseName;
		this.courseFee = courseFee;
	}

	public int getCourseID() {
		return courseID;
	}

	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public float getCourseFee() {
		return courseFee;
	}

	public void setCourseFee(float courseFee) {
		this.courseFee = courseFee;
	}

	@Override
	public String toString() {
		return "Courses [courseID=" + courseID + ", courseName=" + courseName + ", courseFee=" + courseFee + "]";
	}
	
	

}
