package com.edu;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure("hibenate.cfg.xml");
		
		config.addAnnotatedClass(Department.class);
		config.addAnnotatedClass(Employee.class);
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		Department d = new Department("HR", "Bangalore");
		
		Employee e1 = new Employee("Rani", 23);
		Employee e2 = new Employee("Ram", 23);
		
		List<Employee> eList = new ArrayList<Employee>();
		eList.add(e1);
		
		eList.add(e2);
		
		d.setEmplist(eList);
		
		session.save(d);
		
		
		
		tx.commit();
		session.close();
	}

}
