package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainAppProduct {

	public static void main(String[] args) {
		
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		
		config.addAnnotatedClass(Product.class);
		
		config.addAnnotatedClass(Customer.class);
		
		SessionFactory sf = config.buildSessionFactory();
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction();
		
		Product p1 = new Product("TV", 56000.56f); //Transient State
		Product p2 = new Product("Mobile", 6000.56f);
		Product p3 = new Product("Washing Machine", 76000.56f);
		Product p4 = new Product("Heater", 46000.56f);
		Product p5 = new Product("Headphones", 6900.56f);
		
		Customer c1 = new Customer("Bhakti","bhakti@ex.com");
		Customer c2 = new Customer("Ganesh","ganesh@ex.com");
		Customer c3 = new Customer("Vedanti","vedanti@ex.com");
		Customer c4 = new Customer("Ram","ram@ex.com");
		Customer c5 = new Customer("Dev","dev@ex.com");
		
		session.save(p1); ////Persistent State
		session.save(p2);
		session.save(p3);
		session.save(p4);
		session.save(p5);
		
		session.save(c1);
		session.save(c2);
		session.save(c3);
		session.save(c4);
		session.save(c5);
		
		tx.commit();
		
		
		session.close(); // Detached State
		
		// Removed State                 
		//session.delete(p1);
		
		
		
		

	}

}
