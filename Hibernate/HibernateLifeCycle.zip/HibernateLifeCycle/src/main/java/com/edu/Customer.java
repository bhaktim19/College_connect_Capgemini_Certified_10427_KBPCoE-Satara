package com.edu;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Customers")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private int cID;
	
	@Column(name = "Name", length = 50, nullable = false)
	private String cName;
	
	@Column(name = "Email", length = 50, nullable = false)
	private String cMail;
	

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(String cName, String cMail) {
		super();
		this.cName = cName;
		this.cMail = cMail;
	}


	public int getcID() {
		return cID;
	}


	public void setcID(int cID) {
		this.cID = cID;
	}


	public String getcName() {
		return cName;
	}


	public void setcName(String cName) {
		this.cName = cName;
	}


	public String getcMail() {
		return cMail;
	}


	public void setcMail(String cMail) {
		this.cMail = cMail;
	}


	@Override
	public String toString() {
		return "Customer [cID=" + cID + ", cName=" + cName + ", cMail=" + cMail + "]";
	}
	
	
	

}
