package com.edu;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student sob = new Student(2,"Radha");
		Configuration config = new Configuration();
		config.configure("hibernate.cfg.xml");
		
		//convert class to table
		config.addAnnotatedClass(Student.class);
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		
		session.save(sob);
		tx.commit();
		session.close();

	}

}
