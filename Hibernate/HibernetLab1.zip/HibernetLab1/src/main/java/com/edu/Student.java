package com.edu;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity //to make class as table in mysql
public class Student {
    
@Id //studentid becomes a primary key in table
private int studentsid;
private String studentname;


//create constr with no arg
//constr with arg
//setter and getter
//toString

public Student() {
    super();
    // TODO Auto-generated constructor stub
}


public Student(int studentsid, String studentname) {
    super();
    this.studentsid = studentsid;
    this.studentname = studentname;
}


public int getStudentsid() {
    return studentsid;
}


public void setStudentsid(int studentsid) {
    this.studentsid = studentsid;
}


public String getStudentname() {
    return studentname;
}


public void setStudentname(String studentname) {
    this.studentname = studentname;
}


@Override
public String toString() {
    return "Student [studentsid=" + studentsid + ", studentname=" + studentname + "]";
}





}