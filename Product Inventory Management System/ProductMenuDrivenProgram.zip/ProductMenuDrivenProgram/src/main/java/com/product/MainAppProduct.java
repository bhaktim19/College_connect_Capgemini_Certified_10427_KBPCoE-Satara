package com.product;

import java.sql.SQLException;
import java.util.Scanner;

public class MainAppProduct {

	public static void main(String[] args) throws SQLException {
		
		Scanner sc = new Scanner (System.in);
		int ch,choice, mainChoice;
		char c;
		
		System.out.println("Are you Admin or User?");
		System.out.println("1.Admin \n2.User\n3.Exit");
		
		mainChoice = sc.nextInt();
		
		switch(mainChoice) {
		
		case 1://admin 
			
			System.out.println("Enter your Id and Password:");
			String aId,pass;
			aId = sc.next();
			pass = sc.next();
			if(aId.equals("admin")&&pass.equals("admin123")) {//admin validation
				for(;;) {
					System.out.println("***********MENU**********");
					System.out.println("1. Show all products");
					System.out.println("2. Add products");
					System.out.println("3. Remove products");
					System.out.println("4. Update products");
					System.out.println("Enter your choice: ");
					ch = sc.nextInt();
					
					switch (ch) {
					
					case 1://display all products
						ProductDatabaseOperations.displayProducts();
						break;
						
					case 2:// add products
						ProductDatabaseOperations.insertProduct();
						break;
						
					case 3://remove products
						ProductDatabaseOperations.deleteProduct();
						break;
						
					case 4://update products
						ProductDatabaseOperations.updateProduct();
						break;
						
					default:
						System.out.println("Invalid Choice...");
						break;					
					
					}// admin inner switch close
					
					System.out.println("Do you want to continue, press y, press any other key to exit the system...");
					c = sc.next().toLowerCase().charAt(0);
					if (c!='y') {
						System.out.println("Thanks for using the application... \nExiting the program....");
						break;
					}
					
				}//infinite admin close
			}else {
				System.out.println("XXX Access Denied XXX\nSuspicious activity detected. ");
			}//validation close --- case 1 close
			break;
			
		case 2://user
			
			for(;;) {
				
				System.out.println("***********MENU**********");
				System.out.println("1. View all products");
				System.out.println("2. Search Products");//name,category,according to price filter
				System.out.println("Enter your choice: ");
				ch = sc.nextInt();
				
				switch (ch) {
				case 1://view all products
					ProductDatabaseOperations.displayProducts();
					break;
					
				case 2://search products
					ProductDatabaseOperations.searchProduct();
					break;
				
				default:
					System.out.println("Invalid Choice...");
					break;	
				
				}//user inner switch close
				
				System.out.println("Do you want to continue, press y, press any other key to exit the system...");
				c = sc.next().toLowerCase().charAt(0);
				if (c!='y') {
					System.out.println("Thanks for using the application... \nExiting the program....");
					break;
				}
				
			}//infinite user close
			break;
			
		case 3://Exit
			System.out.println("Thanks for using the application... \nExiting the program....");
			System.exit(0);
			
		default:
			System.out.println("Invalid choice ... \nPlease select options from the above list...");
		
		}//main switch close
				

	}// main method close

}//Main class close
