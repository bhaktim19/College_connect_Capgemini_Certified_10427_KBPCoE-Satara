package com.product;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;



public class ProductDatabaseOperations {
	private static Connection conn;
	private static Statement stmt;
	private static ResultSet rs;
	private static Scanner sc = new Scanner(System.in);
	private static String sql;
	private static int i,choice;
	private static int id;
	private static String name;
	private static float price;
	private static int quantity;
	private static String category;

	public static void displayProducts() throws SQLException {
		
		conn = DataBaseConnection.getConnection();
		stmt = conn.createStatement();
		
		sql = "select * from product";
		
		rs = stmt.executeQuery(sql);
		//pid | name      | price | quantity | category
		System.out.printf("%-5s | %-10s | %-10s | %-5s   | %-6s\n","pid", "name", "price", "quantity", "category");
		
		System.out.println("--------------------------------------------------------------");
		
		while (rs.next()) {
			System.out.printf("%-5d | %-10s | %-10.2f | %-10d | %-10s\n",rs.getInt(1),rs.getString(2),rs.getFloat(3),rs.getInt(4),rs.getString(5));
		}
				
	}//displayProducts closed

	public static void insertProduct() throws SQLException {
		
		conn = DataBaseConnection.getConnection();
		stmt = conn.createStatement();
		
		System.out.println("Enter id, name, price, quantity and category: ");
		id = sc.nextInt();
		//check if id already exists
		String checkId = "select * from product where pid ="+id;
		
		rs = stmt.executeQuery(checkId);
		
		if (rs.next()) {
			System.out.println("ID already exists. Please enter a unique ID.");
			return;
		}
		name = sc.next();
		price = sc.nextFloat();
		quantity = sc.nextInt();
		category = sc.next();
		
		String sql = "insert into product values("+id+",'"+name+"',"+price+","+quantity+",'"+category+"')";
		
		int i = stmt.executeUpdate(sql);
		
		if(i>0) {
			System.out.println("Record inserted successfully...");
		}else {
			System.out.println("Some error occurred....");
		}
		
	}//insertProduct close

	public static void deleteProduct() throws SQLException {
		conn = DataBaseConnection.getConnection();
		stmt = conn.createStatement();
		
		System.out.println("Enter id to remove the product: ");
		id = sc.nextInt();
		//check if id already exists
		String checkId = "select * from product where pid ="+id;
		
		rs = stmt.executeQuery(checkId);
		
		if(rs.next()){
			String delsql = "delete from product where pid="+id;
			int i = stmt.executeUpdate(delsql);
			if(i>0) {
				System.out.println("Record is deleted");
			}
			else {
				System.out.println("Some error occurred");
			}
		}
		else {
			System.out.println("Product id not exists");
		}
		
	}//deleteProduct close

	public static void updateProduct() throws SQLException {
		
		conn = DataBaseConnection.getConnection();
		stmt = conn.createStatement();
		
		String checkId = "select * from product where pid ="+id;
		
		rs = stmt.executeQuery(checkId);
		
		if(!rs.next()) {
			System.out.println("Product Id does not exists. Please enter valid product Id....");
			return;
		}else {
		 while(true) {
			System.out.println("Choose the parameter you want to update:");
			System.out.println("1.Name\n2.Price\n3.Quantity\n4.Exit");
			choice = sc.nextInt();
		
			switch(choice) {
			case 1: // update name
				System.out.println("Enter updated product name: ");
				String up_name = sc.next();
				String updtNmaeSql = "update product set name='"+up_name+"' where pid="+id;
				i = stmt.executeUpdate(updtNmaeSql);
				if(i>0) {
					System.out.println("Name is updated...");
				}else {
					System.out.println("Some error occured...");
				}
				break;
				
			case 2: //update price
				System.out.println("Enter updated product price: ");
				float up_price = sc.nextFloat();
				String updtPriceSql = "update product set price="+up_price+"where pid="+id;
				i = stmt.executeUpdate(updtPriceSql);
				if (i>0) {
					System.out.println("Price is updated...");
				}else {
					System.out.println("Some error occured... ");
				}
				break;
				
			case 3: //update Quantity
				System.out.println("Enter updated product quantity: ");
				int up_quantity = sc.nextInt();
				String updtQuantitySql = "update product set quantity="+up_quantity+" where pid="+id;
				//System.out.println(updtQuantitySql);
				i = stmt.executeUpdate(updtQuantitySql);
				if (i>0) {
					System.out.println("Quantity is updated...");
				}else {
					System.out.println("Some error occured... ");
				}
				break;
				
			case 4:
				System.out.println("Thanks for using the application... Exiting....");
				return;	
			
			default:
				System.out.println("Invalid choice....");
				
			}// inner switch close
		}//while close
	}//if close
		
	}//updateProduct close

	public static void searchProduct() throws SQLException {
		
		conn = DataBaseConnection.getConnection();
		stmt = conn.createStatement();
		
		while(true) {
			//name,category,according to price filter
			System.out.println("***********MENU FOR SEARCHING**********");
			System.out.println("1. Search by name");
			System.out.println("2. Search by category");
			System.out.println("3. Search by price filter");
			System.out.println("4. Exit");

			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			
			switch(choice) {
			case 1://name
				
				String name;
				System.out.println("Enter product name to search the product:");
				name = sc.next();
				sql = "select * from product where name='"+name+"'";
				
				rs = stmt.executeQuery(sql);
				//pid | name      | price | quantity | category
				System.out.printf("%-5s | %-10s | %-10s | %-5s   | %-6s\n","pid", "name", "price", "quantity", "category");
				
				System.out.println("--------------------------------------------------------------");
				
				while (rs.next()) {
					System.out.printf("%-5d | %-10s | %-10.2f | %-10d | %-10s\n",rs.getInt(1),rs.getString(2),rs.getFloat(3),rs.getInt(4),rs.getString(5));
				}
				break;
			
			case 2://category
				
				String category;
				System.out.println("Enter product category to search the product:");
				category = sc.next();
				sql = "select * from product where category='"+category+"'";
				
				rs = stmt.executeQuery(sql);
				//pid | name      | price | quantity | category
				System.out.printf("%-5s | %-10s | %-10s | %-5s   | %-6s\n","pid", "name", "price", "quantity", "category");
				
				System.out.println("--------------------------------------------------------------");
				
				while (rs.next()) {
					System.out.printf("%-5d | %-10s | %-10.2f | %-10d | %-10s\n",rs.getInt(1),rs.getString(2),rs.getFloat(3),rs.getInt(4),rs.getString(5));
				}
				break;
			
			case 3://price
				
				float price1,price2;
				System.out.println("Enter product price range to search the product:");
				price1 = sc.nextFloat();
				price2 = sc.nextFloat();
				sql = "select * from product where price between "+price1+" and "+price2;
				
				rs = stmt.executeQuery(sql);
				//pid | name      | price | quantity | category
				System.out.printf("%-5s | %-10s | %-10s | %-5s   | %-6s\n","pid", "name", "price", "quantity", "category");
				
				System.out.println("--------------------------------------------------------------");
				
				while (rs.next()) {
					System.out.printf("%-5d | %-10s | %-10.2f | %-10d | %-10s\n",rs.getInt(1),rs.getString(2),rs.getFloat(3),rs.getInt(4),rs.getString(5));
				}
				break;
				
			case 4:
				System.out.println("Search completed ...Exiting...");
				return;
				
			default:
				System.out.println("Invalid choice....");
				
			}
			
		}//infinite search close
		
	}//searchProduct close

}
